Travis and AppVeyor Scripts
===========================

This directory contains scripts used for testing `ycmd` on Travis and AppVeyor CIs. They
should not normally be run by users.
