package main
func foo() {}
func main() {
    foo()
}
