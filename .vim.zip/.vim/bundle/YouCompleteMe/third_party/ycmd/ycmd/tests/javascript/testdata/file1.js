var global = 'this is a test'

console.log( global );

