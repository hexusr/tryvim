def FlagsForFile( filename ):
  return { 'flags': [] }
