from math import sin
sin
