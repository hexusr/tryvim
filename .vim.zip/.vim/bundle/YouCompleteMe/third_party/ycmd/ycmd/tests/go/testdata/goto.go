package main

func dummy() {

}

func main() {
    dummy() //GoTo
}