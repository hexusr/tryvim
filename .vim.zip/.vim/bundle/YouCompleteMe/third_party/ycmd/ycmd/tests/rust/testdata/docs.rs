mod t {
    /// some docs on a function
    pub fn fun() { }
}

pub fn main() {
    t::fun();
    t::dne();
}
