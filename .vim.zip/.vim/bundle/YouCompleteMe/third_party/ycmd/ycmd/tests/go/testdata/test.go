// Package testdata is dummy data for gocode completion test.
package testdata

import (
	"log"
)

func Hello() {
	log.Logge
}
