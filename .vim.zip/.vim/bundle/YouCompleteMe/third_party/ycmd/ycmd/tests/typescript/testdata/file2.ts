new Bar().testMethod();
