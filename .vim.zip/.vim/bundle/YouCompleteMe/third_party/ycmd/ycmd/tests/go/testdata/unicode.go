package unicode
import ( "fmt" )
type Test struct {
  Unicøde int
}
func main() {
    const test = `unicøde`; fmt.prf
    const test2 = `†es†`; fmt.erro

    å_test := Test{
      Unicøde: 10,
    }
    å_test.
}
