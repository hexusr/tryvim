public class Class
{
    public int attribute;
}
