from goto_file2 import foo
foo
