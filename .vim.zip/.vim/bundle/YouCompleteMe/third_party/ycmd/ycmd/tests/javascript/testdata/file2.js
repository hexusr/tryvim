
console.log( global );

