using System;

namespace testy
{
	public class ContinuousTest
	{
		public static void Main (string[] args)
		{
			var test = String
		}
	}
}
