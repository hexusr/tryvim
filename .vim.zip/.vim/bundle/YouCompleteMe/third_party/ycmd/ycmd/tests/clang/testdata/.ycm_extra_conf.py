def FlagsForFile( filename ):
  return { 'flags': ['-x', 'c++', '-I', '.'] }
