use iron::prelude::*;

/// Parse a file and return a list of issues (warnings, errors) encountered
pub fn parse(_: &mut Request) -> IronResult<Response> {
    unimplemented!();
}
